# OSCA Senior Citizen Information Management System

Starter Laravel application for the thesis project **Digital Transformation in LGU Elderly Care: An Integrated Web Analytics Framework**.

## Modules

- Authentication and role-based access
- Senior citizen registration and records
- QR-code identity verification
- Benefits monitoring
- Reports
- Analytics dashboard
- Basic audit logging
- MySQL database

## Stack

- Laravel 11 / PHP 8.2+
- MySQL
- Blade
- Bootstrap 5 CDN
- Simple QR Code
- XAMPP for local development

## Setup

```bash
git clone <your-repository-url>
cd osca-laravel-starter

composer install
cp .env.example .env
php artisan key:generate
```

Create a MySQL database named `osca_system`, then check `.env`.

```bash
php artisan migrate --seed
php artisan storage:link
php artisan serve
```

Open `http://127.0.0.1:8000`.

### Demo accounts

- Admin: `admin@osca.test` / `password`
- Staff: `staff@osca.test` / `password`

Change these credentials before deployment.

## GitHub

```bash
git init
git add .
git commit -m "Initial OSCA Laravel starter"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/osca-information-management-system.git
git push -u origin main
```

## Important

This is a starter implementation. Before production use, conduct security/privacy review, configure HTTPS, use strong credentials, restrict production debug output, validate the actual OSCA data fields, and obtain appropriate authorization for personal data processing.
